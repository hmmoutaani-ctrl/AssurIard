
// ============================================
// ASSURIARD — INTERACTIONS, FORMULAIRE & SEO
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  // Sticky Header
  const header = document.querySelector('.header');
  const scrollThreshold = 50;
  function updateHeader() {
    if (window.scrollY > scrollThreshold) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  }
  window.addEventListener('scroll', updateHeader, { passive: true });
  updateHeader();

  // Mobile Menu
  const menuBtn = document.querySelector('.mobile-menu-btn');
  const mobileMenu = document.querySelector('.mobile-menu');
  if (menuBtn && mobileMenu) {
    menuBtn.addEventListener('click', () => {
      const isOpen = mobileMenu.classList.toggle('active');
      menuBtn.setAttribute('aria-expanded', isOpen);
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });
    mobileMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mobileMenu.classList.remove('active');
        menuBtn.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });
  }

  // FAQ Accordion
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const answer = item.querySelector('.faq-answer');
      const isActive = item.classList.contains('active');
      document.querySelectorAll('.faq-item').forEach(i => {
        i.classList.remove('active');
        i.querySelector('.faq-answer').style.maxHeight = null;
        i.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
      });
      if (!isActive) {
        item.classList.add('active');
        answer.style.maxHeight = answer.scrollHeight + 'px';
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });

  // Intersection Observer for scroll animations
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
  document.querySelectorAll('.animate').forEach(el => observer.observe(el));

  // Counter Animation
  const counters = document.querySelectorAll('[data-count]');
  const countObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.getAttribute('data-count'));
        const suffix = el.getAttribute('data-suffix') || '';
        const duration = 2000;
        const start = performance.now();
        function update(now) {
          const elapsed = now - start;
          const progress = Math.min(elapsed / duration, 1);
          const ease = 1 - Math.pow(1 - progress, 3);
          const current = Math.floor(ease * target);
          el.textContent = current + suffix;
          if (progress < 1) requestAnimationFrame(update);
          else el.textContent = target + suffix;
        }
        requestAnimationFrame(update);
        countObserver.unobserve(el);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(c => countObserver.observe(c));

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      const target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        const offset = 80;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });

  // Lazy load images
  if ('loading' in HTMLImageElement.prototype) {
    document.querySelectorAll('img[data-src]').forEach(img => {
      img.src = img.dataset.src;
      img.removeAttribute('data-src');
    });
  } else {
    const imgObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          imgObserver.unobserve(img);
        }
      });
    });
    document.querySelectorAll('img[data-src]').forEach(img => imgObserver.observe(img));
  }

  // ============================================
  // FORMULAIRE DEVIS — MODAL & VALIDATION
  // ============================================

  const modalOverlay = document.getElementById('modal-devis');
  const modalClose = document.querySelector('.modal-close');
  const openModalBtns = document.querySelectorAll('[data-open-modal]');

  // Ouvrir modal
  openModalBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (modalOverlay) {
        modalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        const type = btn.getAttribute('data-type');
        if (type) {
          const select = document.getElementById('modal-type');
          if (select) select.value = type;
        }
      }
    });
  });

  // Fermer modal
  function closeModal() {
    if (modalOverlay) {
      modalOverlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  }
  if (modalClose) modalClose.addEventListener('click', closeModal);
  if (modalOverlay) {
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) closeModal();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modalOverlay.classList.contains('active')) closeModal();
    });
  }

  // Validation formulaire inline (page)
  const inlineForm = document.getElementById('devis-form');
  if (inlineForm) initFormValidation(inlineForm);

  // Validation formulaire modal
  const modalForm = document.getElementById('modal-devis-form');
  if (modalForm) initFormValidation(modalForm);

  function initFormValidation(form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let valid = true;

      // Reset errors
      form.querySelectorAll('.form-error').forEach(err => err.classList.remove('visible'));
      form.querySelectorAll('input, select, textarea').forEach(f => f.style.borderColor = '');

      // Required fields
      form.querySelectorAll('[required]').forEach(field => {
        if (!field.value.trim()) {
          valid = false;
          field.style.borderColor = 'var(--danger)';
          const group = field.closest('.form-group');
          const err = group ? group.querySelector('.form-error') : null;
          if (err) err.classList.add('visible');
        }
      });

      // Email validation
      const emailField = form.querySelector('input[type="email"]');
      if (emailField && emailField.value.trim()) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailField.value.trim())) {
          valid = false;
          emailField.style.borderColor = 'var(--danger)';
          const group = emailField.closest('.form-group');
          const err = group ? group.querySelector('.form-error') : null;
          if (err) { err.textContent = 'Veuillez entrer une adresse email valide.'; err.classList.add('visible'); }
        }
      }

      // Phone validation (10 digits)
      const telField = form.querySelector('input[type="tel"]');
      if (telField && telField.value.trim()) {
        const digits = telField.value.replace(/\D/g, '');
        if (digits.length < 9 || digits.length > 12) {
          valid = false;
          telField.style.borderColor = 'var(--danger)';
          const group = telField.closest('.form-group');
          const err = group ? group.querySelector('.form-error') : null;
          if (err) { err.textContent = 'Veuillez entrer un numéro de téléphone valide.'; err.classList.add('visible'); }
        }
      }

      // RGPD checkbox
      const rgpd = form.querySelector('input[name="rgpd"]');
      if (rgpd && !rgpd.checked) {
        valid = false;
        const group = rgpd.closest('.form-group');
        const err = group ? group.querySelector('.form-error') : null;
        if (err) err.classList.add('visible');
      }

      if (valid) {
        const submitBtn = form.querySelector('.form-submit');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Envoi en cours...';

        // Simuler envoi — REMPLACER PAR VOTRE ENDPOINT
        setTimeout(() => {
          form.innerHTML = `
            <div class="form-success">
              <h3>✅ Demande bien reçue !</h3>
              <p>Un expert Assuriard vous rappelle sous <strong>2 heures ouvrables</strong>.<br>Votre dossier est traité avec la plus grande discrétion.</p>
              <a href="tel:+33986874936" class="btn-primary">📞 Nous appeler</a>
            </div>
          `;
        }, 1500);
      }
    });

    // Clear error on input
    form.querySelectorAll('input, select, textarea').forEach(field => {
      field.addEventListener('input', () => {
        field.style.borderColor = '';
        const group = field.closest('.form-group');
        const err = group ? group.querySelector('.form-error') : null;
        if (err) err.classList.remove('visible');
      });
    });
  }

  // Track conversion events
  document.querySelectorAll('a[href^="tel:"], a[href^="https://wa.me"]').forEach(link => {
    link.addEventListener('click', () => {
      console.log('Conversion event:', link.href);
    });
  });
});
